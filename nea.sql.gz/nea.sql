-- phpMyAdmin SQL Dump
-- version 4.9.7deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 09, 2021 at 04:48 PM
-- Server version: 8.0.26-0ubuntu0.21.04.3
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nea`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_info`
--

CREATE TABLE `bill_info` (
  `scno` varchar(255) NOT NULL,
  `cuid` varchar(10) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mdate` date NOT NULL,
  `pre_reading` int DEFAULT NULL,
  `current_reading` int NOT NULL,
  `unit_consumed` int NOT NULL,
  `demand_type` varchar(255) NOT NULL,
  `bill_amount` int NOT NULL,
  `fy` int NOT NULL,
  `months` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bill_info`
--

INSERT INTO `bill_info` (`scno`, `cuid`, `fname`, `mdate`, `pre_reading`, `current_reading`, `unit_consumed`, `demand_type`, `bill_amount`, `fy`, `months`) VALUES
('SC-10101', 'CUS-110101', 'Customer Full Name', '2021-09-01', 3091, 3098, 8, '10A', 930, 2021, 'Sep'),
('SC-1111', 'CUS-1103', 'Lillith Ortiz', '1994-04-13', 1, 10, 11, '5A', 4, 2021, 'Lacota Gilbert'),
('SC-222', 'CUS-2625', 'Winifred Small', '1994-01-03', 8, 1, 7, '5A', 12, 1998, 'Sep');

-- --------------------------------------------------------

--
-- Table structure for table `bill_payment`
--

CREATE TABLE `bill_payment` (
  `pid` int NOT NULL,
  `p_date` date NOT NULL,
  `scno` bigint NOT NULL,
  `amount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill_info`
--
ALTER TABLE `bill_info`
  ADD PRIMARY KEY (`scno`);

--
-- Indexes for table `bill_payment`
--
ALTER TABLE `bill_payment`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill_payment`
--
ALTER TABLE `bill_payment`
  MODIFY `pid` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
